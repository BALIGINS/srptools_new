local HKeys = {
	--[[
	
	Module hkeys								= HKeys()
	
	Table hotkey_data						= hkeys.register(IntList keycombo, Int press_type, Bool blocked, Bool enabled, Func callback, [Args ...])
	Bool result								= hkeys.unregister(Table hotkey_data)
	Bool result								= hkeys.is_registered(Table hotkey_data)
	
	List old_keycombo / nil					= hkeys.ImguiHotkeyEditor(Str str_id, Str str_id2, label, Table hotkey_data, [Int width=200])
	
	------------------------------------------------------------
	
	IntList keycombo						= hkeys.get_keycombo(Table hotkey_data)
	StrList keynames 						= hkeys.get_keynames(Table hotkey_data)
	Int press_type							= hkeys.get_press_type(Table hotkey_data)
	Func callback, List args				= hkeys.get_callback(Table hotkey_data)
	Bool blocked							= hkeys.is_blocked(Table hotkey_data)
	Bool blocked							= hkeys.is_enabled(Table hotkey_data)

	IntList old_keycombo / nil				= hkeys.set_keycombo(Table hotkey_data, IntList keycombo)
	Int old_press_type / nil				= hkeys.set_press_type(Table hotkey_data, Int press_type)
	Bool old_blocked / nil					= hkeys.set_blocked(Table hotkey_data, Bool blocked)
	Bool old_blocked / nil					= hkeys.set_enabled(Table hotkey_data, Bool enabled)
	Func old_callback, List old_args / nil	= hkeys.set_callback(Table hotkey_data, Func callback, [Args ...])
	
	-------------------------------------------------------------
	
	Str hkeys.ImguiHotkeyEditorPromt		= "..."
	
	Bool result								= hkeys.is_keycombo_down(IntList keycombo)
	Bool result								= hkeys.is_key_down(Int vkey)
	IntList down_keycombo					= hkeys.get_down_keycombo()
	StrList down_keynames				 	= hkeys.get_down_keynames()
	
	
	Str keyname								= hkeys.id_to_name(Int vkey)
	Int vkey								= hkeys.name_to_id(Str keyname, [Bool case_sensitive = false])
	StrList keynames						= hkeys.keycombo_to_keynames(IntList keycombo)
	IntList keycombo						= hkeys.keynames_to_keycombo(StrList keynames)
	
	-----------------------------------------------------------------
	
	hkeys.register(...) args:
		
		1. IntList keycombo:
			ID list of virtual keys
		
		2. Int press_type:
			hkeys.DOWN
			hkeys.HOLD (No mouse button support)
			hkeys.UP
			
		3. Bool blocked:
			true - Block a hotkey press from the game or Lua scripts. As well as it possible.
		
		4. Bool enabled
			true - Your hotkey works
		
		5.Func callback:
			It calls on hotkey press
		
		6. Args:
			Arguments for Func callback
	
	----------------------------------------------------------------
	
		Table hotkey_data = {
			keycombo	= IntList keycombo,
			press_type	= Int press_type,	
			blocked		= Bool blocked,
			enabled		= Bool enabled
			callback	= Func callback,	
			args		= List args			
		}
		
	----------------------------------------------------------------
	
		Dict hkeys.KEYS = {
			VK_WHEELDOWN = 0x100,
			VK_WHEELUP = 0x101,
			VK_OEM_PERIOD = 0xBE,
			Etc.
		}
		
		Ussage:
			hkeys.KEYS.VK_WHEELDOWN
			or 
			hkeys.VK_WHEELDOWN
			
	----------------------------------------------------------------
	
		Table hkeys.NAMES = {
			[hkeys.KEYS.VK_WHEELDOWN] = "Wheel Down",
			[hkeys.KEYS.VK_WHEELUP] = "Wheel Up",
			[hkeys.KEYS.VK_OEM_PERIOD] = {'.', '>'},
			Etc.
		}
		
	--]]	
	
	-- ��� ���������� DOWN ���� �� ����������� � ��� � HOLD ?
}
setmetatable(HKeys, {
	__call = function(self)
		return self.__init()
	end
})
function HKeys.__init()
	local self = {}
	
	local vkeys = require 'vkeys'
	local wm = require 'lib.windows.message'
	local bitex = require "bitex"
	
	
	self.VK_WHEELDOWN = 0x100
	self.VK_WHEELUP = 0x101
	
	self.KEYS = {
		VK_WHEELDOWN = self.VK_WHEELDOWN,
		VK_WHEELUP = self.VK_WHEELUP
	}
	
	self.NAMES = {
		[self.KEYS.VK_WHEELDOWN] = "Wheel Down",
		[self.KEYS.VK_WHEELUP] = "Wheel Up",
	}
	
	for key, value in pairs(vkeys) do	
		if key:sub(1, 3) == 'VK_' then
			self.KEYS[key] = value
			self[key] = value
		end
	end
	
	for key, value in pairs(vkeys.key_names) do
		self.NAMES[key] = value
	end
	
	function self.id_to_name(vkey)
		local name = self.NAMES[vkey]
		if type(name) == 'table' then
			return name[1]
		end
		return name
	end
	
	function self.name_to_id(keyname, case_sensitive)
		if not case_sensitive then
			keyname = string.upper(keyname)
		end
		for id, v in pairs(self.NAMES) do
			if type(v) == 'table' then
				for _, v2 in pairs(v) do
					v2 = (case_sensitive) and v2 or string.upper(v2)
					if v2 == keyname then
						return id
					end
				end
			else
				local name = (case_sensitive) and v or string.upper(v)
				if name == keyname then
					return id
				end
			end
		end
	end
	
	
	
	local HK_hotkeys = {}
	local HK_down_keycombo = {}
	local HK_last_down_combokey = nil
	local HK_key_counter = 0
	
	local KE_current_name = nil
	local KE_new_keycombo = nil
	local KE_tick_clock = os.clock()
	local KE_tick_state = true
	local KE_hovered = false
		
	local DOWN_MESSAGES = {
		[wm.WM_KEYDOWN] = true,
		[wm.WM_SYSKEYDOWN] = true,
		[wm.WM_LBUTTONDBLCLK] = true,
		[wm.WM_LBUTTONDOWN] = true,
		[wm.WM_RBUTTONDOWN] = true,
		[wm.WM_MBUTTONDOWN] = true,
		[wm.WM_XBUTTONDOWN] = true,
		[wm.WM_MOUSEWHEEL] = true

	}
	
	local UP_MESSAGES = {
		[wm.WM_KEYUP] = true,
		[wm.WM_SYSKEYUP] = true,
		[wm.WM_LBUTTONDBLCLK] = true,
		[wm.WM_LBUTTONUP] = true,
		[wm.WM_RBUTTONUP] = true,
		[wm.WM_MBUTTONUP] = true,
		[wm.WM_XBUTTONUP] = true,
		[wm.WM_MOUSEWHEEL] = true
	}
	
	local MBUTTON = {
		[wm.WM_LBUTTONDOWN] = self.VK_LBUTTON,
		[wm.WM_LBUTTONUP] = self.VK_LBUTTON,
		[wm.WM_RBUTTONDOWN] = self.VK_RBUTTON,
		[wm.WM_RBUTTONUP] = self.VK_RBUTTON,
		[wm.WM_MBUTTONDOWN] = self.VK_MBUTTON,
		[wm.WM_MBUTTONUP] = self.VK_MBUTTON,
    }
	
	local XBUTTON = {
		self.VK_XBUTTON1,
		self.VK_XBUTTON2
	}
	
	
	local function HIWORD(param)
		return bit.rshift(bit.band(param, 0xffff0000), 16);
	end
	
	
	
	
	
	local function compareKeyCombos(keycombo1, keycombo2)
	
		if #keycombo1 == 0 or keycombo2 == 0 then
			return false
		end
	
        local keycombo1 = {table.unpack(keycombo1)}
        local keycombo2 = {table.unpack(keycombo2)}
    
        local last_key1 = table.remove(keycombo1, #keycombo1)
        local last_key2 = table.remove(keycombo2, #keycombo2)
        
        table.sort(keycombo1)
        table.sort(keycombo2)
    
        table.insert(keycombo1, last_key1)
        table.insert(keycombo2, last_key2)
    
        for index = 1, #keycombo1 do
		
            if keycombo1[index] ~= keycombo2[index] then
                return false
            end
        end
        
        return true
	end
	
	
	local function isDublicateExist(keycombo, press_type)
		
		for index = 1, #HK_hotkeys do
		
			if compareKeyCombos(HK_hotkeys[index].keycombo, keycombo) and HK_hotkeys[index].press_type == press_type then
				return index
			end
		end
	
		return false
	end
	
	
	local function getKeyID(message, wparam, lparam)
		
		if message == wm.WM_XBUTTONDOWN
		or message == wm.WM_XBUTTONUP then
			local btn = HIWORD(wparam)
			
			return XBUTTON[btn]
			
		elseif MBUTTON[message] then
			return MBUTTON[message]
		
		elseif message == wm.WM_MOUSEWHEEL then
			local keystate = bitex.bextract(wparam, 30, 1)
			
			if keystate == 1 then
				return self.VK_WHEELDOWN
			elseif keystate == 0 then
				return self.VK_WHEELUP
			end
		end
		
		local newKeyId = wparam
		local scancode = bitex.bextract(lparam, 16, 8)
		local extend = bitex.bextract(lparam, 24, 1)
	
		if wparam == self.VK_MENU then
		
			if extend == 1 then
				newKeyId = self.VK_RMENU
				
			else
				newKeyId = self.VK_LMENU
			end
			
		elseif wparam == self.VK_SHIFT then
		
			if scancode == 42 then
				newKeyId = self.VK_LSHIFT
				
			elseif scancode == 54 then
				newKeyId = self.VK_RSHIFT
			end
			
		elseif wparam == self.VK_CONTROL then
		
			if extend == 1 then
				newKeyId = self.VK_RCONTROL
				
			else
				newKeyId = self.VK_LCONTROL
			end
		
		end
	   
		return newKeyId
	end
		
		
		
	addEventHandler("onWindowMessage",
		function (message, wparam, lparam)		
	
			if DOWN_MESSAGES[message] then
				local key_id = getKeyID(message, wparam, lparam)
				
				if not HK_down_keycombo[key_id] then
					HK_last_down_combokey = key_id
					HK_key_counter = HK_key_counter + 1
					HK_down_keycombo[key_id] = HK_key_counter
					
					if KE_current_name then
					
						if key_id == self.VK_ESCAPE then
							KE_current_name = nil
						end
						
						consumeWindowMessage(true, true)
						
					else
					
						for index = 1, #HK_hotkeys do
						
							if self.is_keycombo_down(HK_hotkeys[index].keycombo) and HK_hotkeys[index].press_type == self.DOWN then
							
								if HK_hotkeys[index].callback and HK_hotkeys[index].enabled and not (KE_hovered and compareKeyCombos({self.VK_LBUTTON}, HK_down_keycombo)) then
									HK_hotkeys[index].callback(table.unpack(HK_hotkeys[index].args))
								end
								
								if HK_hotkeys[index].blocked then
									consumeWindowMessage(true, true)
								end
							end
						end
					end
					
						
				else
				
					if KE_current_name then
						consumeWindowMessage(true, true)
						
					else
					
						for index = 1, #HK_hotkeys do
						
							if self.is_keycombo_down(HK_hotkeys[index].keycombo) and HK_hotkeys[index].press_type == self.HOLD then
							
								if HK_hotkeys[index].callback and HK_hotkeys[index].enabled and not (KE_hovered and compareKeyCombos({self.VK_LBUTTON}, HK_down_keycombo)) then
									HK_hotkeys[index].callback(table.unpack(HK_hotkeys[index].args))
								end
								
								if HK_hotkeys[index].blocked then
									consumeWindowMessage()
								end
							end
						end
					end
				end
			end
			
			if UP_MESSAGES[message] then
				local key_id = getKeyID(message, wparam, lparam)
				
				HK_last_down_combokey = key_id
				HK_key_counter = HK_key_counter + 1
				HK_down_keycombo[key_id] = HK_key_counter
				
				if HK_down_keycombo[key_id] then
					
					if KE_current_name then
						KE_new_keycombo = self.get_down_keycombo()
						consumeWindowMessage(true, true)
						
					else
					
						for index = 1, #HK_hotkeys do
						
							if self.is_keycombo_down(HK_hotkeys[index].keycombo) and HK_hotkeys[index].press_type == self.UP then
							
								if HK_hotkeys[index].callback and HK_hotkeys[index].enabled and not (KE_hovered and compareKeyCombos({self.VK_LBUTTON}, HK_down_keycombo)) then
									HK_hotkeys[index].callback(table.unpack(HK_hotkeys[index].args))
								end
								
								if HK_hotkeys[index].blocked then
									consumeWindowMessage()
								end
							end
						end
					end
				end
				
				HK_last_down_combokey = nil
				HK_down_keycombo[key_id] = nil
				
				if not next(HK_down_keycombo) then
					HK_key_counter = 0
				end
			end
			
			if message == wm.WM_CHAR then
				
				if KE_current_name then
					consumeWindowMessage(true, true)
					
				else
				
					for index = 1, #HK_hotkeys do
					
						if self.is_keycombo_down(HK_hotkeys[index].keycombo) and (HK_hotkeys[index].press_type == self.DOWN or HK_hotkeys[index].press_type == self.UP or HK_hotkeys[index].press_type == self.HOLD) then
						
							if HK_hotkeys[index].blocked then
								consumeWindowMessage()
							end
						end
					end
				end
			end 
			
			if message == wm.WM_KILLFOCUS then
				HK_last_down_combokey = nil
				HK_down_keycombo = {}
				HK_key_counter = 0
				KE_new_keycombo = nil
				KE_current_name = nil
				KE_tick_clock = os.clock()
				KE_tick_state = true
			end
		end
	)
	
	--------------------------------------
	
	self.DOWN = 1
	self.HOLD = 2
	self.UP = 3
	self.ImguiHotkeyEditorPromt = "..."
		
		
	function self.register(keycombo, press_type, blocked, enabled, callback, ...)
	
		assert(type(keycombo)=="table", ("bad argument #1 to 'register' (table expected, got %s)"):format(type(keycombo)))
		assert(type(press_type)=="number", ("bad argument #2 to 'register' (number expected, got %s)"):format(type(press_type)))
		assert(type(blocked)=="boolean" or not blocked, ("bad argument #3 to 'register' (boolean expected, got %s)"):format(type(blocked)))
		assert(type(enabled)=="boolean" or not enabled, ("bad argument #4 to 'register' (boolean expected, got %s)"):format(type(enabled)))
		assert(type(callback)=="function", ("bad argument #5 to 'register' (function expected, got %s)"):format(type(callback)))
				
		local hotkey_data = {
			keycombo = {table.unpack(keycombo)},
			press_type = press_type,
			blocked = blocked,
			enabled = enabled,
			callback = callback,
			args = {...}
		}
		
		-- clear a duplicate
		local index = isDublicateExist(keycombo, hotkey_data.press_type)
		if index then
			HK_hotkeys[index].keycombo = {}
		end
		
		table.insert(HK_hotkeys, hotkey_data)
		
		return hotkey_data
	end
	
	
	function self.is_registered(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_keycombo' (table expected, got %s)"):format(type(hotkey_data)))
	
		for index = 1, #HK_hotkeys do
		
			if HK_hotkeys[index] == hotkey_data then
				return true
			end
		end
		
		return false
	end
	
	
	function self.is_keycombo_down(keycombo)
		assert(type(keycombo)=="table", ("bad argument #1 to 'is_keycombo_down' (table expected, got %s)"):format(type(keycombo)))
		
		if HK_last_down_combokey ~= keycombo[#keycombo] then
			return false
		end
		
		for index = 1, #keycombo do
			local l_key
			local r_key
			
			if keycombo[index] == self.VK_MENU then
				l_key = self.VK_LMENU
				r_key = self.VK_RMENU
				
			elseif keycombo[index] == self.VK_SHIFT then
				l_key = self.VK_LSHIFT
				r_key = self.VK_RSHIFT
				
			elseif keycombo[index] == self.VK_CONTROL then
				l_key = self.VK_LCONTROL
				r_key = self.VK_RCONTROL
			end
			
			if l_key and r_key then
			
				if not HK_down_keycombo[l_key] and not HK_down_keycombo[r_key] then
					return false
				end
				
			else
			
				if not HK_down_keycombo[keycombo[index]] then
					return false
				end
			end
		end

		return true
	end
	
	function self.is_key_down(vkey)
		assert(type(vkey)=="number", ("bad argument #1 to 'is_key_down' (table expected, got %s)"):format(type(vkey)))
		
		local l_key
		local r_key
		
		if vkey == self.VK_MENU then
			l_key = self.VK_LMENU
			r_key = self.VK_RMENU
			
		elseif vkey == self.VK_SHIFT then
			l_key = self.VK_LSHIFT
			r_key = self.VK_RSHIFT
			
		elseif vkey == self.VK_CONTROL then
			l_key = self.VK_LCONTROL
			r_key = self.VK_RCONTROL
		end
		
		if l_key and r_key then
		
			if not HK_down_keycombo[l_key] and not HK_down_keycombo[r_key] then
				return false
			end
			
		else
		
			if not HK_down_keycombo[vkey] then
				return false
			end
		end


		return true
	end
	
	
	function self.set_keycombo(hotkey_data, keycombo)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_keycombo' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(keycombo)=="table", ("bad argument #2 to 'set_keycombo' (table expected, got %s)"):format(type(keycombo)))
		
		-- clear a duplicate
		local index = isDublicateExist(keycombo, hotkey_data.press_type)
		if index then
			HK_hotkeys[index].keycombo = {}
		end
		
		if self.is_registered(hotkey_data) then
			local old_keycombo = {table.unpack(hotkey_data.keycombo)}
			hotkey_data.keycombo = {table.unpack(keycombo)}
			return old_keycombo
		end
	end
	
	
	
	function self.set_press_type(hotkey_data, press_type)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_press_type' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(press_type)=="number", ("bad argument #2 to 'set_press_type' (table expected, got %s)"):format(type(press_type)))
		
		-- clear a duplicate
		local index = isDublicateExist(hotkey_data.keycombo, press_type)
		
		if index then
			HK_hotkeys[index].keycombo = {}
		end
		
		if self.is_registered(hotkey_data) then
			local old_press_type = hotkey_data.press_type
			hotkey_data.press_type = press_type
			
			return old_press_type
		end		
	end
	
	
	function self.set_blocked(hotkey_data, blocked)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_blocked' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(blocked)=="boolean" or not blocked, ("bad argument #2 to 'set_blocked' (boolean expected, got %s)"):format(type(blocked)))
		
		if self.is_registered(hotkey_data) then
			local old_blocked = hotkey_data.blocked
			hotkey_data.blocked = blocked
			
			return old_blocked
		end	
	end
	
	function self.set_enabled(hotkey_data, enabled)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_blocked' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(enabled)=="boolean" or not enabled, ("bad argument #2 to 'set_blocked' (boolean expected, got %s)"):format(type(enabled)))
		
		if self.is_registered(hotkey_data) then
			local old_enabled = hotkey_data.enabled
			hotkey_data.enabled = enabled
			
			return old_enabled
		end	
	end
	
	
	function self.set_callback(hotkey_data, callback, ...)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_callback' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(callback)=="function" or not callback, ("bad argument #2 to 'set_callback' (function expected, got %s)"):format(type(callback)))
		
		if self.is_registered(hotkey_data) then
			local old_callback = hotkey_data.callback
			local old_args = {table.unpack(hotkey_data.args)}
			hotkey_data.callback = callback
			hotkey_data.args = {...}
			
			return old_callback, old_args
		end
	end
	
	
	function self.get_keycombo(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'set_callback' (table expected, got %s)"):format(type(hotkey_data)))
	
		return {table.unpack(hotkey_data.keycombo)}
	end
	
	
	function self.get_keynames(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'get_keynames' (table expected, got %s)"):format(type(hotkey_data)))
		
		return self.keycombo_to_keynames({table.unpack(hotkey_data.keycombo)})
	end
	
	
	
	function self.get_press_type(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'get_press_type' (table expected, got %s)"):format(type(hotkey_data)))
		
		return hotkey_data.press_type
	end
	
	
	
	function self.is_blocked(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'get_blocked' (table expected, got %s)"):format(type(hotkey_data)))
		
		return hotkey_data.blocked
	end
	
	function self.is_enabled(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'get_blocked' (table expected, got %s)"):format(type(hotkey_data)))
		
		return hotkey_data.enabled
	end
	
	
	function self.get_callback(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'get_callback' (table expected, got %s)"):format(type(hotkey_data)))
				
		return hotkey_data.get_callback, {table.unpack(hotkey_data.args)}
	end
	
	
	
	function self.unregister(hotkey_data)
	
		assert(type(hotkey_data)=="table", ("bad argument #1 to 'unregister' (table expected, got %s)"):format(type(hotkey_data)))
		
		if self.is_registered(hotkey_data) then
			table.remove(HK_hotkeys, index)
			
			return true
			
		else
			return false
		end
	end
	
	
	function self.get_down_keycombo()
		local keys = {}
		
		for key, value in pairs(HK_down_keycombo) do
			table.insert(keys, key)
		end

		table.sort(keys,
			function(a, b)
			
				if HK_down_keycombo[a] < HK_down_keycombo[b] then
					return true
				end
			end
		)
		
		return keys
	end
	
	
	function self.get_down_keynames()
		local keys = self.get_down_keycombo()
		local names = self.keycombo_to_keynames(keys)
		
		return names
	end
	
	
	function self.keycombo_to_keynames(keys)
		local names = {}
		
		for index = 1, #keys do
			table.insert(names, self.id_to_name(keys[index]))
		end
		
		return names
	end
	
	
	function self.keynames_to_keycombo(names)
		local keys = {}
		
		for index = 1, #names do
			table.insert(keys, self.name_to_id(names[index]))
		end
		
		return keys
	end
	
	
	
	--------------- ImguiHotkeyEditor -----------------
	
	function self.ImguiHotkeyEditor(str_id, str_id2, label, hotkey_data, width)
	
		assert(type(str_id)=="string" or not str_id, ("bad argument #1 to 'ImguiHotkeyEditor' (string expected, got %s)"):format(type(str_id)))
		assert(type(str_id2)=="string" or not str_id2, ("bad argument #2 to 'ImguiHotkeyEditor' (string expected, got %s)"):format(type(str_id2)))
		assert(type(hotkey_data)=="table", ("bad argument #3 to 'ImguiHotkeyEditor' (table expected, got %s)"):format(type(hotkey_data)))
		assert(type(width)=="number" or not width, ("bad argument #4 to 'ImguiHotkeyEditor' (number expected, got %s)"):format(type(width)))
	
		local imgui = require "imgui"
		local width = width or 200
		local width2 = 22
		
		if width == 0 then
			width2 = 0
		end
		
		local sKeys
			
		if (KE_current_name == str_id) and not KE_new_keycombo then
			local current_names = self.get_down_keynames()
			
			if #current_names ~= 0 then
				sKeys = table.concat(self.get_down_keynames(), " + ")
				
			else
			
				if (os.clock()-KE_tick_clock) > 0.4 then
					KE_tick_clock = os.clock()
					KE_tick_state = not KE_tick_state
				end
				
				sKeys =  (KE_tick_state and self.ImguiHotkeyEditorPromt) or " "
			end
		
		elseif (KE_current_name == str_id) and KE_new_keycombo then
			sKeys = table.concat(self.keycombo_to_keynames(KE_new_keycombo), " + ")
			
		else
			sKeys = table.concat(self.keycombo_to_keynames(hotkey_data.keycombo), " + ")
		end
		
		imgui.PushStyleVar(imgui.StyleVar.ItemSpacing, imgui.ImVec2(2, 0))
		
			imgui.PushStyleColor(imgui.Col.ButtonActive, imgui.GetStyle().Colors[imgui.Col.ButtonHovered])
			imgui.PushStyleVar(imgui.StyleVar.ButtonTextAlign, imgui.ImVec2(0, 0))
			
				if imgui.Button(sKeys..str_id, imgui.ImVec2(width- width2, 0)) then
					if not KE_current_name then
						KE_new_keycombo = nil
						KE_tick_clock = os.clock()
						KE_tick_state = true
						KE_current_name = str_id
					end
				end
				
				if imgui.IsItemHovered() then
				
					if KE_hovered ~= str_id then
						KE_hovered = str_id
					end
					
				elseif KE_hovered == str_id then
					KE_hovered = nil
				end
				
	
			
			imgui.PopStyleColor()
			imgui.PopStyleVar()
		
			imgui.SameLine()
		
		imgui.PopStyleVar()
		
		local clear = imgui.Button("X"..str_id2, imgui.ImVec2(20, 20))
		
		if imgui.IsItemHovered() then
				
			if KE_hovered ~= "X"..str_id2 then
				KE_hovered = "X"..str_id2
			end
			
		elseif KE_hovered == "X"..str_id2 then
			KE_hovered = nil
		end
		
		
		if label then
			imgui.PushStyleVar(imgui.StyleVar.ItemSpacing, imgui.GetStyle().ItemInnerSpacing)
				imgui.SameLine()
			imgui.PopStyleVar()
				
			imgui.Text(label)
		end
		
		if clear then
			KE_current_name = nil
			return self.set_keycombo(hotkey_data, {})
		end
		
		if (KE_current_name == str_id) and KE_new_keycombo then
			KE_current_name = nil

			return self.set_keycombo(hotkey_data, KE_new_keycombo)	
		end
	end
		
	
	return self
end

return HKeys()