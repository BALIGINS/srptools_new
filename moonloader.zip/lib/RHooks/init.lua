--    | Author: Ega | 
--    | Script for: BlastHack |
--    | Platform: Moonloader |

local RHookInterface = require("RHooks.classes.interface")

RHookInterface.name = "RHook"
RHookInterface.author = "Ega"
RHookInterface.version = "0.1"


return RHookInterface:new()