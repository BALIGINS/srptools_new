local Ecfg = {

	--[[
		Module ecfg				= require("ecfg")
		nil						= ecfg.mkpath(Str filename)
		
		--
		
		Bool result				= ecfg.update(Table old, Table/StrFilename new,  [Bool rewrite=true])
		Bool result				= ecfg.save(Table old, Str filename)
		
		Table loaded / nil		= ecfg.load(Str filename)
		Bool result				= ecfg.set(Str filename, Str/Int key, value)
		Bool result				= ecfg.append(Str filename, value)
		
		--
		
		List loaded / nil		= ecfg.list_load(Str filename)
		Bool result				= ecfg.list_save(Str filename, List new)
		Bool result				= ecfg.list_insert(Str filename, Int index / value, [value])
		Bool result				= ecfg.list_remove(Str filename, [Int index])
		Bool result				= ecfg.list_set(Str filename, Int index, value)
	]]
}

function Ecfg.__init()
	local self = {}

	local function draw_string(str)
		return string.format("%q", str)
	end

	local function draw_key(key)
		if "string" == type(key) and key:match("^[_%a][_%a%d]*$") then
			return key
			
		elseif "number" == type(key) then
			return "["..key.."]"

		else
			return "["..draw_string(key).."]"
		end
	end
	
	local function draw_table(tbl, tab)
		local tab = tab or ""
		local result = {}
		
		for key, value in pairs(tbl) do
			if type(value) == "string" then
				if type(key) == "number" and key <= #tbl then
					table.insert(result, draw_string(value))
					
				else
					table.insert(result, draw_key(key).." = "..draw_string(value))
				end
				
			elseif type(value) == "number" or type(value) == "boolean" then
				if type(key) == "number" and key <= #tbl then
					table.insert(result, tostring(value))
					
				else
					table.insert(result, draw_key(key).." = "..tostring(value))
				end
			
			elseif type(value) == "table" then
				if type(key) == "number" and key <= #tbl then
					table.insert(result, draw_table(value, tab.."\t"))
					
				else
					table.insert(result, draw_key(key).." = "..draw_table(value, tab.."\t"))
				end
				
			else
				if type(key) == "number" and key <= #tbl then
					table.insert(result, draw_string(tostring(value)))
					
				else
					table.insert(result, draw_key(key).." = "..draw_string(tostring(value)))
				end
			end
		end
		
		if #result == 0 and tab == "" then
			return ""
			
		elseif #result == 0 then
			return "{}"
		
		elseif tab == "" then
			return table.concat(result, ",\n")..",\n"
		
		else
			return "{\n"..tab..table.concat(result, ",\n"..tab)..",\n"..tab:sub(2).."}"
		end       
	end
	
	local function draw_value(value, tab)
		if type(value) == "string" then
			return draw_string(value)
		
		elseif type(value) == "number" or type(value) == "boolean" or type(value) == "nil" then
			return tostring(value)
		
		elseif type(value) == "table" then
			return draw_table(value, tab)
			
		else
			return draw_string(tostring(value))
		end
	end
	
	local function draw_list(list)
		local result = {}
	
		for index, value in ipairs(list) do
			table.insert(result, "table.insert(list, "..draw_value(value, "\t")..")")
		end
		
		if #result == 0 then
			return ""
			
		else
			return table.concat(result, "\n").."\n"
		end
	end
	
	function self.list_load(filename, save)
		assert(type(filename)=="string", ("bad argument #1 to 'load' (string expected, got %s)"):format(type(filename)))
		
		local file = io.open(filename, "r")
		
		if file then
			local text = file:read("*all")
			file:close()
			local lua_code = loadstring("local list = {}\n"..text.."\nreturn list")
			
			if lua_code then
				local result = lua_code()
				
				if type(result) == "table" then
					if save then
						self.list_save(filename, result)
					end
					
					return result
				end
			end
		end
	end
	
	function self.list_save(filename, new)
		assert(type(filename)=="string", ("bad argument #1 to 'list_save' (string expected, got %s)"):format(type(filename)))
		assert(type(new)=="table", ("bad argument #2 to 'list_save' (table expected, got %s)"):format(type(new)))
	
		self.mkpath(filename)
		local file = io.open(filename, "w+")
		
		if file then
			local text = draw_list(new)
			file:write(text)
			file:close()
			
			return true
		else
			return false
		end
	end
	
	function self.list_insert(filename, index, value)
		assert(type(filename)=="string", ("bad argument #1 to 'list_insert' (string expected, got %s)"):format(type(filename)))
		
		if value then
			assert(type(index)=="number", ("bad argument #2 to 'list_insert' (number expected, got %s)"):format(type(index)))
		end
		
		local result
		
		if value then
			result = "table.insert(list, "..index..", "..draw_value(value, "\t")..")"
			
		else
			result = "table.insert(list, "..draw_value(index, "\t")..")"
		end
		
		self.mkpath(filename)
		local file = io.open(filename, "a+")
		
		if file then
			file:write(result.."\n")
			file:close()
			return true
			
		else
			return false
		end
	end
	
	function self.list_remove(filename, index)
		assert(type(filename)=="string", ("bad argument #1 to 'list_remove' (string expected, got %s)"):format(type(filename)))
		assert(type(index)=="number" or index == nil, ("bad argument #2 to 'list_remove' (number or nil expected, got %s)"):format(type(index)))
		
		local result
		
		if index then
			result = "table.remove(list, "..index..")"
			
		else
			result = "table.remove(list)"
		end
		
		self.mkpath(filename)
		local file = io.open(filename, "a+")
		
		if file then
			file:write(result.."\n")
			file:close()
			return true
			
		else
			return false
		end
		
	end
	
	function self.list_set(filename, index, value)
		assert(type(filename)=="string", ("bad argument #1 to 'list_set' (string expected, got %s)"):format(type(filename)))
		assert(type(index)=="number", ("bad argument #2 to 'list_set' (number expected, got %s)"):format(type(index)))
		
		local result = "list["..index.."] = "..draw_value(value, "\t")
		
		self.mkpath(filename)
		local file = io.open(filename, "a+")
		
		if file then
			file:write(result.."\n")
			file:close()
			return true
			
		else
			return false
		end
	end
	
	function self.mkpath(filename)
		assert(type(filename)=="string", ("bad argument #1 to 'mkpath' (string expected, got %s)"):format(type(filename)))
	
		local sep, pStr = package.config:sub(1, 1), ""
		local path = filename:match("(.+"..sep..").+$") or filename
		
		for dir in path:gmatch("[^" .. sep .. "]+") do
			pStr = pStr .. dir .. sep
			createDirectory(pStr)
		end
	end
	
	function self.load(filename, save)
		assert(type(filename)=="string", ("bad argument #1 to 'load' (string expected, got %s)"):format(type(filename)))
	
		local file = io.open(filename, "r")
		
		if file then 	
			local text = file:read("*all")
			file:close()
			local lua_code = loadstring("return {"..text.."}")
			
			if lua_code then
				local result = lua_code()
				
				if type(result) == "table" then
					if save then
						self.save(filename, result)
					end
					
					return result
				end
			end
		end
	end
	
	function self.save(filename, new)
		assert(type(filename)=="string", ("bad argument #1 to 'save' (string expected, got %s)"):format(type(filename)))
		assert(type(new)=="table", ("bad argument #2 to 'save' (table expected, got %s)"):format(type(new)))
	
		self.mkpath(filename)
		local file = io.open(filename, "w+")
		
		if file then
			local text = draw_table(new)
			file:write(text)
			file:close()
			
			return true
		else
			return false
		end
	end
	
	function self.append(filename, value)
		assert(type(filename)=="string", ("bad argument #1 to 'append' (string expected, got %s)"):format(type(filename)))
		
		self.mkpath(filename)
		local file = io.open(filename, "a+")
		
		if file then
			file:write(draw_value(value, "\t")..",\n")
			file:close()
			
			return true
		else
			return false
		end
	end
	
	function self.set(filename, key, value)
		assert(type(filename)=="string", ("bad argument #1 to 'set' (string expected, got %s)"):format(type(filename)))
		assert(type(key)=="string" or type(key)=="number", ("bad argument #2 to 'set' (string or number expected, got %s)"):format(type(key)))
		
		self.mkpath(filename)
		local file = io.open(filename, "a+")
		
		if file then		
			file:write("\n"..draw_key(key).." = "..draw_value(value)..",")
			file:close()
			
			return true
		else
			return false
		end
	end
	
	function self.update(old, new, overwrite)
		assert(type(old)=="table", ("bad argument #1 to 'update' (table expected, got %s)"):format(type(old)))
		assert(type(new)=="string" or type(new)=="table", ("bad argument #2 to 'update' (string or table expected, got %s)"):format(type(new)))
		
		if overwrite == nil then
			overwrite = true
		end
	
		if type(new) == "table" then
			if overwrite then
				for key, value in pairs(new) do
					old[key] = value
				end
				
			else
				for key, value in pairs(new) do
					if not old[key] then
						old[key] = value
					end
				end
			end
			
			return true
			
		elseif type(new) == "string" then
			local loaded = self.load(new)
			
			if loaded then
				if overwrite then
					for key, value in pairs(loaded) do
						old[key] = value
					end
					
				else
					for key, value in pairs(loaded) do
						if not old[key] then
							old[key] = value
						end
					end
				end
				
				return true
			end
		end
		
		return false
	end
	
	return self
end

setmetatable(Ecfg, {
	__call = function(self)
		return self.__init()
	end
})

return Ecfg()




